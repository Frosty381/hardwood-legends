CYBER FIRST GAME BATCH

Upload cyber-strike.html, neon-runner.html and dungeon-quest.html into the ROOT of your GitHub repository beside index.html and game.html.

To show their Play cards on CYBER, copy the three article blocks in GAME-CARDS-SNIPPET.html and paste them inside the existing <div class="game-grid"> in index.html before that grid's closing </div>. Commit the change. Keep your existing index.html, game.html and Supabase settings. No build step or extra library is needed.
